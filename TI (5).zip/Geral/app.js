
function leDados() {
    let strDados = localStorage.getItem('db');
    let objDados = {};

    if (strDados) {
        objDados = JSON.parse(strDados);
    } else {
        objDados = {
            quadras: [
                {
                    nome: "Espaço W11",
                    foto: "https://naquadra.com.br/anexos/Foto154.Jpg",
                    endereco: "Rua General Vasconcelos, 485 - Estoril, Belo Horizonte",
                    lat: -19.9588326, 
                    lng: -43.9664912,
                    preco: "280",
                    descricao: "Duas quadras society desponiveis para aluguel de segunda a quinta, de 14 a 22 horas. Sexta até de 12 as 24. Sábado e Domingo somente com agendamentos prévios.",
                    id: 0,
                    avaliacao: 0

                },
                {
                    nome: "La Bombonera",
                    foto: "https://lh5.googleusercontent.com/p/AF1QipPtw9MeWBZKGd_aQJ7RlYIXGeVhgdBdJ_yU83kz=w280-h209-k-no",
                    endereco: "Av. Professor Mário Werneck, 569 - Buritis, Belo Horizonte",
                    lat: -19.9687925, 
                    lng: -43.961286,
                    preco: "320",
                    descricao: "Duas quadras society desponiveis para aluguel todos os dias de 8:00 as 00:00",
                    id: 1,
                    avaliacao: 5
                },

                {
                    nome: "Vila Rica",
                    foto: "https://gerenciador.webquadras.com.br/resources/uploaded-files/sport_center_photo/5102/image.jpg",
                    endereco: "Rua Vila Rica, 1114 - Padre Eustáquio, Belo Horizonte",
                    lat: -19.911107,
                    lng: -43.980555,
                    preco: "220",
                    descricao: "Somos um clube esportivo no qual temos uma quadra de cimento disponível para aluguel. Nosso horário de funcionamento é todos os dias de 8:00 às 23:00.  ",
                    id: 2,
                    avaliacao: 3
                },

                {
                    nome: "Clube Recreativo",
                    foto: "https://static.wixstatic.com/media/0a2af6_7beb8d909bad432fbc779e6fe23167c5~mv2.jpeg/v1/fill/w_448,h_265,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/WhatsApp%20Image%202023-01-23%20at%2016_28_59.jpeg",
                    endereco: "R. Grão Mogol, 197 - Carmo, Belo Horizonte ",
                    lat: -19.9418945, 
                    lng: -43.9338455,
                    preco: "360",
                    descricao: "Quadra de grama sintética. Horário de funcionamento: Segunda - fechado para manutenção - Terça a Sexta - 08:00 às 20:00 - Sábado e Domingo - 8:00 as 18:00",
                    id: 3,
                    avaliacao: 4
                },

                {
                    nome: "Arena Serra",
                    foto: "https://lh3.googleusercontent.com/p/AF1QipME0nV3fqn6Md9YgMj2mDez3NkinEA2gRMedoia=w960-h960-n-o-v1",
                    endereco: "R. Laguna, 9 - Serra, Belo Horizonte",
                    preco: "270",
                    lat: -19.9380432, 
                    lng: -43.9185754,
                    descricao: "Quadra de Futebol Society, Escolinha, Espaço para Eventos, Bar. Horário de Funcionamento: Segunda a Sexta - 010:00 às 22:00 - Sábado e Domingo - 8:00 as 20:00",
                    id: 4,
                    avaliacao: 2
                },

                {
                    nome: "Arena Sion",
                    foto: "https://lh3.googleusercontent.com/p/AF1QipPG2LNnOEwoAH6PkUXjdSx6Yxt0FAdqkenejyLS=w1080-h608-p-no-v0",
                    endereco: "Rua Washington, 925 - Sion, Belo Horizonte",
                    lat: -19.9515399, 
                    lng: -43.9396896,
                    preco: "300",
                    descricao: "Escola de Futebol ABA / Quadra de Esportes / Locação de Espaço / Cross Soccer. Horário de Funcionamento: Segunda a Sexta - 010:00 às 22:00 - Sábado e Domingo - 8:00 as 20:00",
                    id: 5,
                    avaliacao: 5
                } 

            ]
        };

        localStorage.setItem('db', JSON.stringify(objDados));
    }

    return objDados;
}

function imprimeDados () {
    let tela = document.getElementById('tela');
    let strHtml = '';
    let objDados = leDados (); 
    for (let  i = 0; i < objDados.quadras.length; i++){
        strHtml += `<div class="carda">
        <img src="${objDados.quadras[i].foto}" alt="Imagem Quadra 1">
        <div class="card-contenta">
            <h2 class="card-titlea">${objDados.quadras[i].nome}</h2>
            <p class="card-pricea">Preço (1 hora): ${objDados.quadras[i].preco}</p>
            <p class="card-ratinga">Avaliação: ${objDados.quadras[i].avaliacao}</P>
            <button class="card-buttona" onclick="redirectToDetalhes(${objDados.quadras[i].id})">Saiba mais</button>
            <br>
            <br>
            <button class="card-buttona" onclick="redirectToAvaliacao(${objDados.quadras[i].id})"> Avaliar </button>

        </div>
        </div>`;
    }

    tela.innerHTML = strHtml;
}

imprimeDados();


// Configuração dos botões


function redirectToDetalhes(productId) {
    window.location.href = 'detalhes.html?id=' + productId;
}

function redirectToAvaliacao(productId){
    window.location.href = 'avaliacao.html?id=' + productId;
}

// Filtro 


document.getElementById('ordenacao').addEventListener('change', function() {
    const ordenacaoSelect = document.getElementById('ordenacao');
    const escolhaUsuario = ordenacaoSelect.value;
    let objDados = leDados ();

    if (escolhaUsuario === "crescente") {
        objDados.quadras.sort((a, b) => parseFloat(a.preco) - parseFloat(b.preco));
    } else if (escolhaUsuario === "decrescente") {
        objDados.quadras.sort((a, b) => parseFloat(b.preco) - parseFloat(a.preco));
    } else if (escolhaUsuario === "nenhum") {
        objDados.quadras.sort((a, b) => a.id - b.id);
    }

    localStorage.setItem('db', JSON.stringify(objDados));

    imprimeDados();

});

// mapa

function initMap() {
    var map = new google.maps.Map(document.getElementById('map'), {
      center: { lat: -19.919221, lng: -43.938685 },
      zoom: 12
    });

    var objDados = leDados(); // Chama a função para obter os dados do banco

    var markers = [];

    objDados.quadras.forEach(function (quadra) {
      var marker = new google.maps.Marker({
        position: { lat: quadra.lat, lng: quadra.lng },
        map: map,
        title: quadra.nome
      });

      marker.addListener('click', function () {
        var infoCard = document.getElementById('info-card');
        var locationTitle = document.getElementById('location-title');
        var locationDetails = document.getElementById('location-details');
        locationTitle.textContent = quadra.nome;
        locationDetails.textContent = quadra.endereco;
        infoCard.style.display = 'block';
      });

      markers.push(marker);
    });
  }

