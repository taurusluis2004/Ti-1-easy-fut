document.addEventListener('DOMContentLoaded', function() {
  var form = document.getElementById('criarJogoForm');

  form.addEventListener('submit', function(event) {
      event.preventDefault(); 

      var local = document.getElementById('local').value;
      var data = document.getElementById('data').value;
      var horario = document.getElementById('horario').value;


      var tabela = document.createElement('table');
      tabela.innerHTML = `
          <tr>
              <th>Local</th>
              <th>Data</th>
              <th>Horário</th>
          </tr>
          <tr>
              <td>${local}</td>
              <td>${data}</td>
              <td>${horario}</td>
          </tr>
      `;


      var container = document.querySelector('.container');
      container.appendChild(tabela);


      var mensagem = document.createElement('p');
      mensagem.textContent = 'Jogo criado com sucesso!';
      container.appendChild(mensagem);
  });
});

document.addEventListener('DOMContentLoaded', function() {
  var form = document.getElementById('criarJogoForm');
  form.style.height = window.innerHeight - form.offsetTop + 'px';
});


