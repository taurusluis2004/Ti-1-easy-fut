var threads=[

    {
        id:1,
        title:"Forum 1",
        author:"Pedro",
        date:Date.now(),
        content:"Thread content",
        comments:[
            {
                author:"Pedro",
                date:Date.now(),
                content:"Jogo as 19:00?"
            },
            {
                author:"Arthur",
                date:Date.now(),
                content:"vamos!"
            }
            
        ]
    },
    {
        id:2,
        title:"Forum 2",
        author:"Miguel",
        date:Date.now(),
        content:"Thread content",
        comments:[
            {
                author:"ciro",
                date:Date.now(),
                content:"eai beleza"
            },
            {
                author:"Silva",
                date:Date.now(),
                content:"tudo joia"
            }
            
        ]
    },
    
]
if(localStorage&&localStorage.getItem('threads')){
    threads=JSON.parse(localStorage.getItem('threads'));

}
