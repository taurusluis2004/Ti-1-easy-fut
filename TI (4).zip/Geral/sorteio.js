document.addEventListener("DOMContentLoaded", function () {
  const sortearEquipesBtn = document.getElementById("sortearEquipes");
  const adicionarJogadorBtn = document.getElementById("adicionarJogador");
  const equipeA = document.getElementById("equipeA");
  const equipeB = document.getElementById("equipeB");
  const novoJogadorInput = document.getElementById("novoJogador");
  const jogadoresList = document.getElementById("jogadoresList");

  let jogadores = [];

  adicionarJogadorBtn.addEventListener("click", function () {
    const nomeJogador = novoJogadorInput.value;
    if (nomeJogador) {
      jogadores.push(nomeJogador);
      novoJogadorInput.value = "";

      const numeroJogador = jogadores.length;
      jogadoresList.innerHTML += `<li>${numeroJogador}. ${nomeJogador}</li>`;

      if (jogadores.length === 10) {
        adicionarJogadorBtn.disabled = true;
        sortearEquipesBtn.disabled = false;
      }
    }
  });

  sortearEquipesBtn.addEventListener("click", function () {
    if (jogadores.length === 10) {
      jogadores = shuffleArray(jogadores);

      const metade = Math.ceil(jogadores.length / 2);
      const equipeAArray = jogadores.slice(0, metade);
      const equipeBArray = jogadores.slice(metade);

      renderEquipe(equipeAArray, equipeA.querySelector("ul"));
      renderEquipe(equipeBArray, equipeB.querySelector("ul"));
    } else {
      alert("Por favor, insira os nomes de todos os 10 jogadores antes de sortear as equipes.");
    }
  });

  function renderEquipe(equipe, ulElement) {
    ulElement.innerHTML = "";
    equipe.forEach(function (jogador) {
      const li = document.createElement("li");
      li.textContent = jogador;
      ulElement.appendChild(li);
    });
  }

  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }
});
